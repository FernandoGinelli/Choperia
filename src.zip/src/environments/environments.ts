export const environment = {
  production: false,
  emailService: {
    host: 'smtp.example.com',
    port: 587,
    secure: false,
    auth: {
      user: 'seu-email@example.com',
      pass: 'sua-senha-de-email'
    }
  }
};
