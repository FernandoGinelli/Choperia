import { Component } from '@angular/core';
import type { OnInit } from '@angular/core';

/* @figmaId 3:23 */
@Component({
  selector: 'cli-buttontype-ok',
  templateUrl: './buttontype-ok.component.html',
  styleUrls: ['./buttontype-ok.component.css'],
})
export class ButtontypeOkComponent implements OnInit {
  constructor() {}
  ngOnInit(): void {}
}
